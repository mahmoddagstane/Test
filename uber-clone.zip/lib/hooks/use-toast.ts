import { useToast as useHookToast } from "@/hooks/use-toast"

export const useToast = useHookToast
