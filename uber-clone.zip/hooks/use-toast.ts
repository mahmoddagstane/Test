import { useToast as useToastHook } from "@/components/ui/use-toast"

export const useToast = useToastHook
